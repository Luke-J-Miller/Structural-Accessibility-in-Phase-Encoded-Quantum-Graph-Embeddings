"""Constants of the shot-count proposition for the pair census, PE-X1 at the schedule, n = 14.

For the complete connected cubic census at n = 14 and a grid of mixer angles beta, computes
  * the class values f(a,k), the least gap Delta between realized classes, the range F = max f - min f and F_max = max |f|,
    and the two-defect weight mu_2 = c^4 s^{2(n-2)};
  * the first-order window hypothesis (W): eps(beta) = max over graphs and two-defect outcomes of
    |p(x;beta)/mu_2 - 1 - beta f(a,k)|, reported as the ratio eps/(beta Delta), which (W) requires to be at most 1/4;
  * the upper bound N_up = 51 log(n^2/delta) / (beta^2 mu_2 Delta^2) at delta = 0.01;
  * for one switch pair (G, H) of the census with different pair censuses: the two-defect Hellinger sum
    D = sum_{|D(x)|=2} (sqrt p_G - sqrt p_H)^2, the layer masses, the lower bound N_low = (1 - P) / (4 D), the a priori
    bound on D from the proposition, the number of pairs whose class changes, and, for comparison, the squared Hellinger
    distance of the full labelled distributions and the corresponding bound 1 / (8 H^2).
Probabilities are exact dense statevectors (PE-X1, Qiskit convention, little-endian bit order; defects are zero bits)."""
import itertools
import math
import subprocess
import time
import numpy as np
import networkx as nx

ETA, GAMMA = 23 / 8, 2.0
n = 14
c_eta, s_eta = math.cos(ETA / 2), math.sin(ETA / 2)
t = s_eta / c_eta
mu2 = c_eta ** 4 * s_eta ** (2 * (n - 2))
h = [math.cos(GAMMA * (2 * k - 3)) for k in range(4)]


def class_value(a, k):
    return ((n - 8 + 2 * a + k) * h[0] + (6 - 2 * a - 2 * k) * h[1] + k * h[2]) / t - 2 * t * h[a]


classes = [(0, 0), (0, 1), (0, 2), (0, 3), (1, 0), (1, 1), (1, 2)]
f = {cls: class_value(*cls) for cls in classes}
values = sorted(f.values())
Delta = min(b - a for a, b in zip(values, values[1:]))
F = values[-1] - values[0]
F_max = max(abs(v) for v in values)
print(f"n={n}, PE-X1 at the schedule: t^2={t*t:.4f}, mu_2={mu2:.6e}")
print("class values f(a,k): " + ", ".join(f"({a},{k}): {f[(a,k)]:.4f}" for a, k in classes))
print(f"Delta (least gap) = {Delta:.6f}, Delta_k = {f[(0,1)]-f[(0,0)]:.6f}, Delta_a = {f[(1,0)]-f[(0,0)]:.4f}, F = {F:.4f}, F_max = {F_max:.4f}")
print(f"heuristic scale 1/(beta^2 mu_2 Delta^2) at beta = 0.1: {1/(0.01*mu2*Delta**2):.3e}")


def dense_probabilities(adjacency, beta):
    c_beta, s_beta = math.cos(beta / 2), math.sin(beta / 2)
    mixer = np.array([[c_beta, -1j * s_beta], [-1j * s_beta, c_beta]])
    xs = np.arange(2 ** n)
    bits = (xs[:, None] >> np.arange(n)[None, :]) & 1
    amplitude = np.prod(np.where(bits == 0, c_eta, -1j * s_eta), axis=1)
    z = 1 - 2 * bits
    for u, v in zip(*np.triu_indices(n, 1)):
        if adjacency[u, v]:
            amplitude = amplitude * np.exp(-0.5j * GAMMA * z[:, u] * z[:, v])
    state = amplitude
    for v in range(n):
        reshaped = state.reshape(2 ** (n - v - 1), 2, 2 ** v)
        state = np.einsum("xy,ayb->axb", mixer, reshaped).reshape(-1)
    return np.abs(state) ** 2


def two_defect_index(u, v):
    return 2 ** n - 1 - 2 ** u - 2 ** v


lines = subprocess.run(["nauty-geng", "-c", "-d3", "-D3", "-q", str(n)], capture_output=True, text=True).stdout.split()
census = [nx.to_numpy_array(nx.from_graph6_bytes(line.encode()), dtype=int) for line in lines]
print(f"census: {len(census)} graphs")
pairs = list(itertools.combinations(range(n), 2))
indices = np.array([two_defect_index(u, v) for u, v in pairs])

betas = [2.5e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2]
delta = 0.01
print("\n(W) on the census, and the upper bound at delta = 0.01:")
print(f"{'beta':>8} {'eps/(beta Delta)':>18} {'(W) holds':>10} {'beta(Fmax+Delta/4)':>20} {'N_up':>12}")
window = {}
for beta in betas:
    started = time.time()
    eps = 0.0
    for adjacency in census:
        p = dense_probabilities(adjacency, beta)
        common = adjacency @ adjacency
        for (u, v), index in zip(pairs, indices):
            predicted = 1 + beta * f[(int(adjacency[u, v]), int(common[u, v]))]
            eps = max(eps, abs(p[index] / mu2 - predicted))
    ratio = eps / (beta * Delta)
    holds = ratio <= 0.25 and beta * (F_max + Delta / 4) <= 0.5
    window[beta] = holds
    n_up = 51 * math.log(n * n / delta) / (beta ** 2 * mu2 * Delta ** 2)
    print(f"{beta:8.2e} {ratio:18.4f} {str(holds):>10} {beta*(F_max+Delta/4):20.4f} {n_up:12.3e}   ({time.time()-started:.0f}s)")

# a switch pair with different pair censuses
def pair_census(adjacency):
    common = adjacency @ adjacency
    census_ = {}
    for u, v in pairs:
        key = (int(adjacency[u, v]), int(common[u, v]))
        census_[key] = census_.get(key, 0) + 1
    return tuple(sorted(census_.items()))


rng = np.random.default_rng(0)
G = census[0]
H = None
while H is None:
    a, b = pairs[rng.integers(len(pairs))]
    c, d = pairs[rng.integers(len(pairs))]
    if len({a, b, c, d}) < 4 or not (G[a, b] and G[c, d]) or G[a, c] or G[b, d]:
        continue
    candidate = G.copy()
    candidate[a, b] = candidate[b, a] = 0
    candidate[c, d] = candidate[d, c] = 0
    candidate[a, c] = candidate[c, a] = 1
    candidate[b, d] = candidate[d, b] = 1
    if pair_census(candidate) != pair_census(G) and nx.is_connected(nx.from_numpy_array(candidate)):
        H = candidate
        switch = (a, b, c, d)
print(f"\nswitch pair: census graph 0 ({lines[0]}) and the graph with edges {switch[0]}{switch[1]}, {switch[2]}{switch[3]} replaced by "
      f"{switch[0]}{switch[2]}, {switch[1]}{switch[3]}; isomorphic: {nx.is_isomorphic(nx.from_numpy_array(G), nx.from_numpy_array(H))}")
commonG, commonH = G @ G, H @ H
changed = sum(1 for u, v in pairs if (G[u, v], commonG[u, v]) != (H[u, v], commonH[u, v]))
print(f"pairs whose class changes: {changed} (at most 4n-10 = {4*n-10}); pair census of G: {pair_census(G)}; of H: {pair_census(H)}")
print(f"\n{'beta':>8} {'D (two-defect)':>15} {'P':>10} {'N_low=(1-P)/(4D)':>18} {'D bound':>12} {'H^2 (labelled)':>15} {'1/(8H^2)':>12}")
for beta in betas:
    pG, pH = dense_probabilities(G, beta), dense_probabilities(H, beta)
    D = float(np.sum((np.sqrt(pG[indices]) - np.sqrt(pH[indices])) ** 2))
    P = max(pG[indices].sum(), pH[indices].sum())
    n_low = (1 - P) / (4 * D)
    D_bound = mu2 * beta ** 2 * (math.comb(n, 2) * Delta ** 2 / 8 + (2 * n - 5) * (F + Delta / 2) ** 2)
    H2 = 0.5 * float(np.sum((np.sqrt(pG) - np.sqrt(pH)) ** 2))
    print(f"{beta:8.2e} {D:15.4e} {P:10.4e} {n_low:18.4e} {D_bound:12.4e} {H2:15.4e} {1/(8*H2):12.4e}")
print("\n(W) holds at:", [beta for beta in betas if window[beta]])
