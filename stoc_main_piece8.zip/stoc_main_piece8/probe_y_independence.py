"""Are the four PE-Y1 coefficients {sin3g/t, sin g/t, t sin3g, t sin g} linearly independent over Q at the schedule
eta = 23/8, gamma = 2?  Dividing by sin(gamma)/t this is independence of {1, s, t^2, s t^2} with s = sin^2(gamma)
and t^2 = tan^2(eta/2).  Both are rational functions of u = exp(i/8) (gamma = 16/8, eta = 23/8), and u is
transcendental by Lindemann-Weierstrass, so a rational relation holds iff it holds identically in u.  The check is
the rank of the coefficient matrix of four Laurent polynomials in u.  A PSLQ search on the numerical values is run
as an independent sanity check."""
import sympy
import mpmath

u = sympy.symbols('u')
cos_gamma_double = (u**32 + u**(-32)) / 2          # cos(2 gamma) = cos 4 with gamma = 2 = 16/8
sin_squared_gamma = (1 - cos_gamma_double) / 2      # s = sin^2(gamma) = (1 - cos 2gamma)/2
cos_eta = (u**23 + u**(-23)) / 2                    # cos(eta), eta = 23/8
t_squared_numerator = 1 - cos_eta                   # t^2 = (1 - cos eta)/(1 + cos eta)
t_squared_denominator = 1 + cos_eta

# Multiply every basis element by the common denominator (1 + cos eta) and by u^55 to clear negative powers.
clearing_factor = t_squared_denominator * u**55
basis = {
    "1":      sympy.expand(1 * clearing_factor),
    "s":      sympy.expand(sin_squared_gamma * clearing_factor),
    "t^2":    sympy.expand(t_squared_numerator * u**55),
    "s t^2":  sympy.expand(sin_squared_gamma * t_squared_numerator * u**55),
}
polynomials = {name: sympy.Poly(expression, u) for name, expression in basis.items()}
all_monomials = sorted({monomial for poly in polynomials.values() for monomial in poly.as_dict()}, reverse=True)
coefficient_matrix = sympy.Matrix([[poly.as_dict().get(monomial, 0) for monomial in all_monomials]
                                   for poly in polynomials.values()])
print("monomial exponents present:", [m[0] for m in all_monomials])
print("coefficient matrix (rows 1, s, t^2, s t^2):")
sympy.pprint(coefficient_matrix)
rank = coefficient_matrix.rank()
print("rank over Q:", rank, "of 4 ->", "INDEPENDENT" if rank == 4 else "DEPENDENT")
assert rank == 4

# Numerical sanity check: PSLQ should find no small integer relation among the four actual coefficients.
mpmath.mp.dps = 60
eta = mpmath.mpf(23) / 8
gamma = mpmath.mpf(2)
t = mpmath.tan(eta / 2)
coefficients = [mpmath.sin(3 * gamma) / t, mpmath.sin(gamma) / t, t * mpmath.sin(3 * gamma), t * mpmath.sin(gamma)]
relation = mpmath.pslq(coefficients, maxcoeff=10**6, maxsteps=10**6)
print("PSLQ relation with coefficients up to 1e6:", relation)
assert relation is None
print("numerical values:", [mpmath.nstr(c, 12) for c in coefficients])
