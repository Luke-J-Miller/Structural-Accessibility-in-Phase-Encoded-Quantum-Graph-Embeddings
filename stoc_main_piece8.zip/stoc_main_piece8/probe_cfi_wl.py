"""Which WL level distinguishes the CFI pairs over small base graphs, in the four-pins-per-edge construction
whose vertex count matches QuIC (sum_v 2^{d_v-1} + 4|E|: P3 -> 12, P12 -> 66, C4 -> 24, K3 -> 18, K5 -> 80)?
Checks colour refinement (1-WL) and folklore 2-WL on the untwisted/twisted pair."""
import itertools
import networkx as nx


def cfi_pair(B):
    """Fürer-style CFI graphs over base graph B: inner vertices (v,S) for even S subset of E(v); pins (v,e,i), i in {0,1};
    inner (v,S) ~ (v,e,1) for e in S and (v,e,0) otherwise; pins across an edge e=uv joined (u,e,i)~(v,e,i), crossed
    on one twisted edge."""
    edges = [tuple(sorted(e)) for e in B.edges()]
    inc = {v: [e for e in edges if v in e] for v in B.nodes()}

    def build(twist_edge):
        G = nx.Graph()
        for v in B.nodes():
            d = len(inc[v])
            for r in range(0, d + 1, 2):
                for S in itertools.combinations(inc[v], r):
                    node = ("in", v, S)
                    G.add_node(node)
                    for e in inc[v]:
                        G.add_edge(node, ("pin", v, e, 1 if e in S else 0))
        for e in edges:
            u, v = e
            for i in (0, 1):
                j = 1 - i if e == twist_edge else i
                G.add_edge(("pin", u, e, i), ("pin", v, e, j))
        return G

    return build(None), build(edges[0])


def colour_refinement_multiset(G, rounds=None):
    col = {v: 0 for v in G}
    rounds = rounds or G.number_of_nodes()
    for _ in range(rounds):
        new = {v: (col[v], tuple(sorted(col[w] for w in G[v]))) for v in G}
        ids = {}
        col = {v: ids.setdefault(new[v], len(ids)) for v in G}
    return sorted(col.values())


def one_wl_distinguishes(G, H):
    """Run refinement jointly on the disjoint union and compare colour multisets."""
    U = nx.disjoint_union(G, H)
    nG = G.number_of_nodes()
    col = {v: 0 for v in U}
    for _ in range(U.number_of_nodes()):
        new = {v: (col[v], tuple(sorted(col[w] for w in U[v]))) for v in U}
        ids = {}
        col = {v: ids.setdefault(new[v], len(ids)) for v in U}
    a = sorted(col[v] for v in U if v < nG)
    b = sorted(col[v] for v in U if v >= nG)
    return a != b


def two_fwl_distinguishes(G, H):
    U = nx.disjoint_union(G, H)
    nG = G.number_of_nodes()
    nodes = list(U.nodes())
    A = {v: set(U[v]) for v in nodes}
    col = {}
    ids = {}
    for u in nodes:
        for v in nodes:
            key = (u == v, v in A[u])
            col[(u, v)] = ids.setdefault(key, len(ids))
    for _ in range(40):
        new = {}
        for u in nodes:
            for v in nodes:
                ms = sorted((col[(w, v)], col[(u, w)]) for w in nodes if (w < nG) == (u < nG))
                new[(u, v)] = (col[(u, v)], tuple(ms))
        ids = {}
        col2 = {k: ids.setdefault(val, len(ids)) for k, val in new.items()}
        if len(set(col2.values())) == len(set(col.values())):
            col = col2
            break
        col = col2
    a = sorted(col[(u, v)] for u in nodes for v in nodes if u < nG and v < nG)
    b = sorted(col[(u, v)] for u in nodes for v in nodes if u >= nG and v >= nG)
    return a != b


bases = {
    "P3": nx.path_graph(3), "P4": nx.path_graph(4), "P6": nx.path_graph(6),
    "C4": nx.cycle_graph(4), "C5": nx.cycle_graph(5),
    "Pan4": nx.lollipop_graph(4, 1), "K3": nx.complete_graph(3), "K4": nx.complete_graph(4),
    "Star4": nx.star_graph(4), "K23": nx.complete_bipartite_graph(2, 3),
}
for name, B in bases.items():
    G, H = cfi_pair(B)
    assert G.number_of_nodes() == H.number_of_nodes()
    iso = nx.is_isomorphic(G, H)
    d1 = one_wl_distinguishes(G, H)
    d2 = two_fwl_distinguishes(G, H) if G.number_of_nodes() <= 40 else None
    comps = (nx.number_connected_components(G), nx.number_connected_components(H))
    print(f"{name:6s} |V|={G.number_of_nodes():3d} isomorphic={iso} components={comps} "
          f"1-WL distinguishes={d1} 2-FWL distinguishes={d2}")
