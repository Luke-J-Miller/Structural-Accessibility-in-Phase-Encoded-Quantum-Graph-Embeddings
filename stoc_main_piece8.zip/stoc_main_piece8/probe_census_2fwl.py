"""Does folklore 2-WL separate every pair of the complete connected cubic census at n = 16 and n = 18?

Census: nauty-geng -c -d3 -D3 n, generator order, digest printed as in the paper.  Each graph gets a canonical
folklore 2-WL colouring: the colour of a pair after a round is a 64-bit hash of (its previous colour, the sorted
multiset over w of the hashed pair (colour[w,v], colour[u,w])).  Hashes are built from structure only, so equal
stable multisets across graphs mean the graphs are candidates for 2-WL equivalence; every candidate pair is then
confirmed by exact joint refinement (two_fwl_distinguishes from probe_cfi_wl.py), which has no hashing.  The round
count is fixed and checked to exceed stabilization for every graph."""
import subprocess
import sys
import time
import hashlib
import numpy as np
import networkx as nx

import os
cfi_source = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "probe_cfi_wl.py")).read()
exec(cfi_source.split("bases = {")[0])        # defines two_fwl_distinguishes (exact, hash-free)

MIX_A = np.uint64(0x9E3779B97F4A7C15)
MIX_B = np.uint64(0xC2B2AE3D27D4EB4F)
MIX_C = np.uint64(0x165667B19E3779F9)
ROUNDS = 10


def mix_pair(a, b):
    """64-bit hash of an ordered pair of 64-bit values (wraparound arithmetic, graph-independent)."""
    with np.errstate(over="ignore"):
        h = a * MIX_A + b * MIX_B + MIX_C
        h ^= h >> np.uint64(29)
        h *= MIX_A
        h ^= h >> np.uint64(32)
    return h


def canonical_two_fwl_colours(adjacency, rounds):
    """Canonical folklore 2-WL colours of all pairs after a fixed number of rounds, and the round at which the
    partition stabilized."""
    n = adjacency.shape[0]
    colour = np.where(np.eye(n, dtype=bool), 2, adjacency).astype(np.uint64)
    stabilized_at = None
    previous_classes = len(np.unique(colour))
    for round_index in range(1, rounds + 1):
        left = np.broadcast_to(colour[:, None, :], (n, n, n))      # colour[u, w]
        right = np.broadcast_to(colour.T[None, :, :], (n, n, n))   # colour[w, v]
        combined = np.sort(mix_pair(right, left), axis=2)
        row_hash = np.zeros((n, n), dtype=np.uint64)
        for w in range(n):
            row_hash = mix_pair(row_hash, combined[:, :, w])
        colour = mix_pair(colour, row_hash)
        classes = len(np.unique(colour))
        if classes == previous_classes and stabilized_at is None:
            stabilized_at = round_index
        previous_classes = classes
    return colour, stabilized_at


n = int(sys.argv[1])
started = time.time()
graph6_lines = subprocess.run(["nauty-geng", "-c", "-d3", "-D3", "-q", str(n)], capture_output=True, text=True).stdout.split()
digest = hashlib.sha256("\n".join(graph6_lines).encode()).hexdigest()[:16]
print(f"n={n}: {len(graph6_lines)} connected cubic graphs, digest {digest} ({time.time()-started:.1f}s)")
signatures = {}
latest_stabilization = 0
for index, line in enumerate(graph6_lines):
    adjacency = nx.to_numpy_array(nx.from_graph6_bytes(line.encode()), dtype=int)
    colour, stabilized_at = canonical_two_fwl_colours(adjacency, ROUNDS)
    assert stabilized_at is not None and stabilized_at < ROUNDS, (index, stabilized_at)
    latest_stabilization = max(latest_stabilization, stabilized_at)
    signature = hashlib.sha256(np.sort(colour.flatten()).tobytes()).hexdigest()
    signatures.setdefault(signature, []).append(index)
    if (index + 1) % 5000 == 0:
        print(f"  {index+1}/{len(graph6_lines)} graphs, {len(signatures)} classes so far, {time.time()-started:.0f}s")
collisions = {sig: members for sig, members in signatures.items() if len(members) > 1}
print(f"stable folklore 2-WL classes: {len(signatures)} of {len(graph6_lines)} graphs; latest stabilization round {latest_stabilization}; "
      f"candidate classes with more than one graph: {len(collisions)}")
confirmed_pairs = 0
for sig, members in collisions.items():
    for i in range(len(members)):
        for j in range(i + 1, len(members)):
            g = nx.from_graph6_bytes(graph6_lines[members[i]].encode())
            h = nx.from_graph6_bytes(graph6_lines[members[j]].encode())
            assert not nx.is_isomorphic(g, h)
            distinguished = two_fwl_distinguishes(g, h)
            print(f"  candidate pair census indices {members[i]}, {members[j]}: exact joint 2-FWL distinguishes = {distinguished}; "
              f"graph6 {graph6_lines[members[i]]} ; {graph6_lines[members[j]]}")
            if not distinguished:
                confirmed_pairs += 1
print(f"confirmed folklore-2-WL-equivalent nonisomorphic pairs at n={n}: {confirmed_pairs}  (total {time.time()-started:.0f}s)")
