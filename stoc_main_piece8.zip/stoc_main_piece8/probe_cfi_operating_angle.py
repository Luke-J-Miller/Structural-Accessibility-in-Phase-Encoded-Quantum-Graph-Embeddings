"""A folklore-2-WL-equivalent cubic pair and the PE-X1 sorted readout at the operating angle.

Self-contained run of record for the appendix on Cai-Furer-Immerman pairs.  Stages:
  B. CFI pairs over the cubic base graphs K4, prism, K3,3, cube, Petersen (four pins per edge, so the pair is cubic
     on 10 n_B vertices): isomorphism, colour refinement, exact folklore 2-WL (joint refinement, no hashing), and the
     first-order histograms of the extremal counts (E_in, E_out) and of the odd readings on the layers with 2, 3, 4
     defects (through 6 defects for the pair over K4).
  C. Exact Born probabilities of PE-X1 at the schedule (eta, gamma, beta) = (23/8, 2, 1/10) for the pair over K4 by
     variable elimination of the two-state partition function
        A(x) = sum_y prod_v [R_X(beta)]_{x_v y_v} a(y_v) prod_{uv in E} exp(-i gamma z_u z_v / 2),
     validated against a dense statevector at n = 10; every outcome with at most four defects; the shell bounds P_ell
     of Lemma B.33, which certify that the outcomes with at most two defects are ranks 1..K_2(40) and that the computed
     outcomes above P_5 are the first ranks of the sorted readout; sorted comparison of the two graphs layer by layer
     and over those ranks; pointwise comparison with the shared vertex labels.
  D. The modal outcome at 50, 80 and 120 decimal digits, and an outward-rounded interval enclosure (60 digits) of
     p_untwisted(1^40) - p_twisted(1^40) that excludes zero.
Usage: python3 probe_cfi_operating_angle.py [--skip-layer4]"""
import itertools
import math
import os
import sys
import time
import numpy as np
import networkx as nx
import mpmath

SKIP_LAYER4 = "--skip-layer4" in sys.argv
ETA, GAMMA, BETA = 23 / 8, 2.0, 0.1


def log(message):
    print(message, flush=True)


# ----------------------------------------------------------------------------------------------------------------
# construction and refinement
# ----------------------------------------------------------------------------------------------------------------
def cfi_pair(base):
    """Untwisted and twisted CFI graphs over base (Furer gadget): inner vertices (v,S) for even S subset of E(v),
    pins (v,e,i) for i in {0,1}; (v,S) ~ (v,e,[e in S]); pins across an edge e = uv joined (u,e,i) ~ (v,e,i),
    crossed on the one twisted edge.  Over a cubic base both graphs are cubic with 10 n_B vertices."""
    edges = [tuple(sorted(e)) for e in base.edges()]
    incident = {v: [e for e in edges if v in e] for v in base.nodes()}

    def build(twist_edge):
        graph = nx.Graph()
        for v in base.nodes():
            for r in range(0, len(incident[v]) + 1, 2):
                for S in itertools.combinations(incident[v], r):
                    node = ("in", v, S)
                    graph.add_node(node)
                    for e in incident[v]:
                        graph.add_edge(node, ("pin", v, e, 1 if e in S else 0))
        for e in edges:
            u, v = e
            for i in (0, 1):
                j = 1 - i if e == twist_edge else i
                graph.add_edge(("pin", u, e, i), ("pin", v, e, j))
        return graph

    return build(None), build(edges[0])


def one_wl_distinguishes(G, H):
    """Colour refinement run jointly on the disjoint union; compares the stable colour multisets."""
    U = nx.disjoint_union(G, H)
    n_G = G.number_of_nodes()
    colour = {v: 0 for v in U}
    for _ in range(U.number_of_nodes()):
        new = {v: (colour[v], tuple(sorted(colour[w] for w in U[v]))) for v in U}
        ids = {}
        colour = {v: ids.setdefault(new[v], len(ids)) for v in U}
    return sorted(colour[v] for v in U if v < n_G) != sorted(colour[v] for v in U if v >= n_G)


def two_fwl_distinguishes(G, H):
    """Exact folklore 2-WL run jointly on the disjoint union (pairs within one graph), to stabilization."""
    U = nx.disjoint_union(G, H)
    n_G = G.number_of_nodes()
    nodes = list(U.nodes())
    adjacency = {v: set(U[v]) for v in nodes}
    ids = {}
    colour = {(u, v): ids.setdefault((u == v, v in adjacency[u]), len(ids)) for u in nodes for v in nodes}
    for _ in range(60):
        new = {}
        for u in nodes:
            for v in nodes:
                multiset = sorted((colour[(w, v)], colour[(u, w)]) for w in nodes if (w < n_G) == (u < n_G))
                new[(u, v)] = (colour[(u, v)], tuple(multiset))
        ids = {}
        refined = {key: ids.setdefault(value, len(ids)) for key, value in new.items()}
        stable = len(set(refined.values())) == len(set(colour.values()))
        colour = refined
        if stable:
            break
    a = sorted(colour[(u, v)] for u in nodes for v in nodes if u < n_G and v < n_G)
    b = sorted(colour[(u, v)] for u in nodes for v in nodes if u >= n_G and v >= n_G)
    return a != b


# ----------------------------------------------------------------------------------------------------------------
# first-order histograms
# ----------------------------------------------------------------------------------------------------------------
def layer_histograms(graph, layer_size):
    """Histograms over all layer_size-subsets D of (E_in, E_out) and of the odd readings
    (q3-q0, q2-q1) inside and outside D."""
    adjacency = nx.to_numpy_array(graph, dtype=np.int64)
    n = adjacency.shape[0]
    extremal_histogram, odd_histogram = {}, {}
    for defect_set in itertools.combinations(range(n), layer_size):
        defect_list = list(defect_set)
        counts = adjacency[:, defect_list].sum(axis=1)
        inside = counts[defect_list]
        mask = np.ones(n, dtype=bool)
        mask[defect_list] = False
        outside = counts[mask]
        q_in = [int((inside == k).sum()) for k in range(4)]
        q_out = [int((outside == k).sum()) for k in range(4)]
        extremal = (q_in[0] + q_in[3], q_out[0] + q_out[3])
        odd = (q_in[3] - q_in[0], q_in[2] - q_in[1], q_out[3] - q_out[0], q_out[2] - q_out[1])
        extremal_histogram[extremal] = extremal_histogram.get(extremal, 0) + 1
        odd_histogram[odd] = odd_histogram.get(odd, 0) + 1
    return extremal_histogram, odd_histogram


def differing_keys(histogram_a, histogram_b):
    keys = set(histogram_a) | set(histogram_b)
    return sorted(k for k in keys if histogram_a.get(k, 0) != histogram_b.get(k, 0))


# ----------------------------------------------------------------------------------------------------------------
# exact contraction (double precision)
# ----------------------------------------------------------------------------------------------------------------
c_eta, s_eta = math.cos(ETA / 2), math.sin(ETA / 2)
c_beta, s_beta = math.cos(BETA / 2), math.sin(BETA / 2)
mixer_matrix = np.array([[c_beta, -1j * s_beta], [-1j * s_beta, c_beta]])      # R_X(beta), rows x_v, columns y_v
preparation_amplitude = np.array([c_eta, -1j * s_eta])                          # a(0), a(1)
edge_phase = np.array([[np.exp(-0.5j * GAMMA), np.exp(0.5j * GAMMA)],
                       [np.exp(0.5j * GAMMA), np.exp(-0.5j * GAMMA)]])          # exp(-i gamma z_u z_v / 2) by (y_u, y_v)


def elimination_order(graph):
    """Greedy minimum-fill elimination order on a copy of the graph; returns the order and the largest clique met."""
    working = graph.copy()
    order, width = [], 0
    while working.number_of_nodes() > 0:
        best_vertex, best_fill = None, None
        for vertex in working.nodes():
            neighbours = list(working[vertex])
            fill = sum(1 for a, b in itertools.combinations(neighbours, 2) if not working.has_edge(a, b))
            if best_fill is None or fill < best_fill or (fill == best_fill and working.degree(vertex) < working.degree(best_vertex)):
                best_vertex, best_fill = vertex, fill
        neighbours = list(working[best_vertex])
        width = max(width, len(neighbours))
        for a, b in itertools.combinations(neighbours, 2):
            working.add_edge(a, b)
        working.remove_node(best_vertex)
        order.append(best_vertex)
    return order, width


def contract_amplitude(graph, order, outcome_bits):
    """A(x) by variable elimination; factors are (variables, complex array) merged on elimination with einsum."""
    factors = []
    for vertex in graph.nodes():
        factors.append(((vertex,), mixer_matrix[outcome_bits[vertex], :] * preparation_amplitude))
    for u, v in graph.edges():
        factors.append(((u, v), edge_phase))
    for vertex in order:
        touching = [f for f in factors if vertex in f[0]]
        factors = [f for f in factors if vertex not in f[0]]
        variables = []
        for vars_, _ in touching:
            for var in vars_:
                if var not in variables:
                    variables.append(var)
        letters = {var: chr(97 + i) for i, var in enumerate(variables)}
        assert len(variables) <= 20, len(variables)
        subscripts = ",".join("".join(letters[var] for var in vars_) for vars_, _ in touching)
        remaining = [var for var in variables if var != vertex]
        merged = np.einsum(subscripts + "->" + "".join(letters[var] for var in remaining), *[arr for _, arr in touching], optimize=True)
        factors.append((tuple(remaining), merged))
    result = 1.0 + 0j
    for vars_, arr in factors:
        assert vars_ == ()
        result = result * arr
    return complex(result)


def dense_probabilities(graph):
    """Reference: dense statevector of PE-X1 for a small graph, little-endian bit order."""
    n = graph.number_of_nodes()
    xs = np.arange(2 ** n)
    bits = (xs[:, None] >> np.arange(n)[None, :]) & 1
    amplitude = np.prod(np.where(bits == 0, c_eta, -1j * s_eta), axis=1)
    z = 1 - 2 * bits
    for u, v in graph.edges():
        amplitude = amplitude * np.exp(-0.5j * GAMMA * z[:, u] * z[:, v])
    state = amplitude
    for v in range(n):
        reshaped = state.reshape(2 ** (n - v - 1), 2, 2 ** v)
        state = np.einsum("xy,ayb->axb", mixer_matrix, reshaped).reshape(-1)
    return np.abs(state) ** 2


def shell_bound(n, defects):
    """P_ell of Lemma B.33: p(x) <= P_ell for every outcome with ell defects, every cubic graph."""
    return ((c_beta * c_eta + s_beta * s_eta) ** defects * (c_beta * s_eta + s_beta * c_eta) ** (n - defects)) ** 2


# ----------------------------------------------------------------------------------------------------------------
# high precision and interval arithmetic
# ----------------------------------------------------------------------------------------------------------------
def contract_amplitude_generic(graph, order, outcome_bits, mixer, prep, phase, one, zero):
    """A(x) by variable elimination with factors as dicts from bit assignments to numbers of any arithmetic type."""
    factors = []
    for vertex in graph.nodes():
        factors.append(((vertex,), {(y,): mixer[(outcome_bits[vertex], y)] * prep[y] for y in (0, 1)}))
    for u, v in graph.edges():
        factors.append(((u, v), {(a, b): phase[(a, b)] for a in (0, 1) for b in (0, 1)}))
    for vertex in order:
        touching = [f for f in factors if vertex in f[0]]
        factors = [f for f in factors if vertex not in f[0]]
        variables = []
        for vars_, _ in touching:
            for var in vars_:
                if var not in variables:
                    variables.append(var)
        remaining = [var for var in variables if var != vertex]
        merged = {}
        for assignment in itertools.product((0, 1), repeat=len(variables)):
            lookup = dict(zip(variables, assignment))
            value = one
            for vars_, table in touching:
                value = value * table[tuple(lookup[var] for var in vars_)]
            key = tuple(lookup[var] for var in remaining)
            merged[key] = merged.get(key, zero) + value
        factors.append((tuple(remaining), merged))
    result = one
    for vars_, table in factors:
        assert vars_ == ()
        result = result * table[()]
    return result


def mp_constants():
    """Gate entries as mpmath complex numbers at the current working precision."""
    eta, gamma, beta = mpmath.mpf(23) / 8, mpmath.mpf(2), mpmath.mpf(1) / 10
    I = mpmath.mpc(0, 1)
    ce, se = mpmath.cos(eta / 2), mpmath.sin(eta / 2)
    cb, sb = mpmath.cos(beta / 2), mpmath.sin(beta / 2)
    mixer = {(0, 0): mpmath.mpc(cb), (1, 1): mpmath.mpc(cb), (0, 1): -I * sb, (1, 0): -I * sb}
    prep = {0: mpmath.mpc(ce), 1: -I * se}
    phase = {(0, 0): mpmath.exp(-I * gamma / 2), (1, 1): mpmath.exp(-I * gamma / 2),
             (0, 1): mpmath.exp(I * gamma / 2), (1, 0): mpmath.exp(I * gamma / 2)}
    return mixer, prep, phase, mpmath.mpc(1), mpmath.mpc(0)


class IntervalComplex:
    """Complex number with real-interval parts, for outward-rounded arithmetic (addition and multiplication only)."""
    __slots__ = ("re", "im")

    def __init__(self, re, im):
        self.re, self.im = re, im

    def __add__(self, other):
        return IntervalComplex(self.re + other.re, self.im + other.im)

    def __mul__(self, other):
        return IntervalComplex(self.re * other.re - self.im * other.im, self.re * other.im + self.im * other.re)

    def modulus_squared(self):
        return self.re * self.re + self.im * self.im


def iv_constants():
    """Gate entries as interval complex numbers at the current interval precision."""
    iv = mpmath.iv
    eta, gamma, beta = iv.mpf(23) / 8, iv.mpf(2), iv.mpf(1) / 10
    ce, se = iv.cos(eta / 2), iv.sin(eta / 2)
    cb, sb = iv.cos(beta / 2), iv.sin(beta / 2)
    cg, sg = iv.cos(gamma / 2), iv.sin(gamma / 2)
    zero, one = iv.mpf(0), iv.mpf(1)
    mixer = {(0, 0): IntervalComplex(cb, zero), (1, 1): IntervalComplex(cb, zero),
             (0, 1): IntervalComplex(zero, -sb), (1, 0): IntervalComplex(zero, -sb)}
    prep = {0: IntervalComplex(ce, zero), 1: IntervalComplex(zero, -se)}
    phase = {(0, 0): IntervalComplex(cg, -sg), (1, 1): IntervalComplex(cg, -sg),       # exp(-i gamma/2)
             (0, 1): IntervalComplex(cg, sg), (1, 0): IntervalComplex(cg, sg)}         # exp(+i gamma/2)
    return mixer, prep, phase, IntervalComplex(one, zero), IntervalComplex(zero, zero)


# ----------------------------------------------------------------------------------------------------------------
# stage B: pairs, refinement, first-order histograms
# ----------------------------------------------------------------------------------------------------------------
log("== Stage B: CFI pairs over cubic base graphs, refinement and first-order histograms")
base_graphs = {"K4": nx.complete_graph(4), "prism": nx.circular_ladder_graph(3), "K3,3": nx.complete_bipartite_graph(3, 3),
               "cube": nx.hypercube_graph(3), "Petersen": nx.petersen_graph()}
pairs = {}
for base_name, base in base_graphs.items():
    base = nx.convert_node_labels_to_integers(base)
    assert all(d == 3 for _, d in base.degree())
    untwisted, twisted = cfi_pair(base)
    assert list(untwisted.nodes()) == list(twisted.nodes())
    labels = {node: i for i, node in enumerate(untwisted.nodes())}
    untwisted, twisted = nx.relabel_nodes(untwisted, labels), nx.relabel_nodes(twisted, labels)
    pairs[base_name] = (untwisted, twisted)
    n = untwisted.number_of_nodes()
    assert all(d == 3 for _, d in untwisted.degree()) and all(d == 3 for _, d in twisted.degree())
    started = time.time()
    isomorphic = nx.is_isomorphic(untwisted, twisted)
    one_wl = one_wl_distinguishes(untwisted, twisted)
    two_wl = two_fwl_distinguishes(untwisted, twisted) if n <= 60 else None
    log(f"CFI over {base_name}: n={n}, cubic, connected={nx.is_connected(untwisted)}, isomorphic={isomorphic}, "
        f"1-WL distinguishes={one_wl}, folklore 2-WL distinguishes={two_wl}, girth={nx.girth(untwisted)}, {nx.girth(twisted)}  ({time.time()-started:.1f}s)")
    if n <= 60:
        cycle_counts = []
        for graph in (untwisted, twisted):
            counts = {5: 0, 6: 0}
            for cycle in nx.simple_cycles(graph, length_bound=6):
                if len(cycle) in counts:
                    counts[len(cycle)] += 1
            cycle_counts.append((counts[5], counts[6]))
        log(f"  (C_5, C_6): untwisted {cycle_counts[0]}, twisted {cycle_counts[1]}")
    top_layer = 6 if n == 40 else (4 if n <= 60 else 3)
    for layer_size in range(2, top_layer + 1):
        started = time.time()
        extremal_u, odd_u = layer_histograms(untwisted, layer_size)
        extremal_t, odd_t = layer_histograms(twisted, layer_size)
        extremal_diff = differing_keys(extremal_u, extremal_t)
        odd_diff = differing_keys(odd_u, odd_t)
        log(f"  layer {layer_size}: {sum(extremal_u.values())} subsets; (E_in,E_out) histogram keys differing: {len(extremal_diff)}; "
            f"odd-reading histogram keys differing: {len(odd_diff)}; distinct (E_in,E_out) keys {len(extremal_u)}, odd keys {len(odd_u)}  ({time.time()-started:.1f}s)")
        for key in extremal_diff[:4]:
            log(f"      (E_in,E_out)={key}: untwisted {extremal_u.get(key, 0)}, twisted {extremal_t.get(key, 0)}")
        for key in odd_diff[:4]:
            log(f"      odd={key}: untwisted {odd_u.get(key, 0)}, twisted {odd_t.get(key, 0)}")

# ----------------------------------------------------------------------------------------------------------------
# stage C: the pair over K4 at the schedule
# ----------------------------------------------------------------------------------------------------------------
log("== Stage C: PE-X1 at the schedule on the pair over K4, by exact contraction")
test_graph = nx.random_regular_graph(3, 10, seed=1)
reference = dense_probabilities(test_graph)
order, width = elimination_order(test_graph)
worst = 0.0
for x in range(2 ** 10):
    outcome_bits = [(x >> v) & 1 for v in range(10)]
    worst = max(worst, abs(abs(contract_amplitude(test_graph, order, outcome_bits)) ** 2 - reference[x]))
log(f"validation on a random cubic graph at n=10 (all 1024 outcomes): worst |p_contraction - p_dense| = {worst:.2e}")
assert worst < 1e-13

untwisted, twisted = pairs["K4"]
graphs = {"untwisted": untwisted, "twisted": twisted}
n = 40
differing_edges = sorted(set(untwisted.edges()) ^ set(twisted.edges()))
log(f"shared vertex labels; edges that differ between the two graphs: {differing_edges}")
orders = {}
for name, graph in graphs.items():
    orders[name], width = elimination_order(graph)
    log(f"  {name}: elimination order found, largest eliminated neighbourhood {width}")
P = {k: shell_bound(n, k) for k in range(7)}
log("shell bounds P_ell at n=40 and the schedule: " + ", ".join(f"P_{k}={P[k]:.4e}" for k in range(7)))
mu = {k: c_eta ** (2 * k) * s_eta ** (2 * (n - k)) for k in range(6)}
log("zero-angle layer weights mu_ell at n=40: " + ", ".join(f"mu_{k}={mu[k]:.4e}" for k in range(6)))

top = 4 if not SKIP_LAYER4 else 3
values = {name: {} for name in graphs}            # values[name][layer] = dict defect_set -> probability
for layer_size in range(0, top + 1):
    started = time.time()
    for name, graph in graphs.items():
        table = {}
        for defect_set in itertools.combinations(range(n), layer_size):
            outcome_bits = [0 if v in defect_set else 1 for v in range(n)]
            table[defect_set] = abs(contract_amplitude(graph, orders[name], outcome_bits)) ** 2
        values[name][layer_size] = table
    log(f"layer {layer_size}: {len(values['untwisted'][layer_size])} outcomes per graph computed ({time.time()-started:.0f}s)")

# layer statistics, head membership, sorted comparison
for layer_size in range(0, top + 1):
    a = np.sort(np.array(list(values["untwisted"][layer_size].values())))[::-1]
    b = np.sort(np.array(list(values["twisted"][layer_size].values())))[::-1]
    log(f"layer {layer_size}: untwisted max {a[0]:.6e} min {a[-1]:.6e}; twisted max {b[0]:.6e} min {b[-1]:.6e}; "
        f"max |sorted difference| {np.abs(a-b).max():.3e}, L1 {np.abs(a-b).sum():.3e}")
pooled = {}
for name in graphs:
    modal = values[name][0][()]
    largest = {k: max(values[name][k].values()) for k in range(1, top + 1)}
    smallest = {k: min(values[name][k].values()) for k in range(0, top + 1)}
    head2_min = min(smallest[k] for k in range(0, 3))
    log(f"{name}: p(1^40) = {modal:.15e}; largest one-defect value {largest[1]:.6e}; smallest value with <=2 defects {head2_min:.6e} "
        f"vs largest three-defect value {largest[3]:.6e} and P_3 = {P[3]:.6e} -> outcomes with <=2 defects occupy ranks 1..{sum(math.comb(n, k) for k in range(3))}: "
        f"{head2_min > P[3]}")
    if top >= 4:
        layer3 = np.array(list(values[name][3].values()))
        layer4 = np.array(list(values[name][4].values()))
        log(f"{name}: smallest three-defect value {smallest[3]:.6e} vs largest four-defect value {largest[4]:.6e} and P_4 = {P[4]:.6e}: "
            f"three-defect values below the largest four-defect value: {int((layer3 < largest[4]).sum())} of {len(layer3)}; "
            f"four-defect values above the smallest three-defect value: {int((layer4 > smallest[3]).sum())} of {len(layer4)}")
        log(f"{name}: four-defect values above P_5 = {P[5]:.6e}: {int((layer4 > P[5]).sum())} of {len(layer4)}; "
            f"all values with <=3 defects above P_5: {smallest[3] > P[5]}")
    pooled[name] = np.sort(np.concatenate([list(values[name][k].values()) for k in range(0, top + 1)]))[::-1]
    np.save(os.path.join(os.path.dirname(os.path.abspath(__file__)), f"cfi_k4_pooled_{name}.npy"), pooled[name])
count_u, count_t = int((pooled["untwisted"] > P[top + 1]).sum()), int((pooled["twisted"] > P[top + 1]).sum())
log(f"computed outcomes (<= {top} defects) above P_{top+1}: {count_u} (untwisted), {count_t} (twisted); these are ranks 1..{count_u} of each sorted readout")
assert count_u == count_t
certified_u, certified_t = pooled["untwisted"][:count_u], pooled["twisted"][:count_t]
difference = np.abs(certified_u - certified_t)
log(f"ranks 1..{count_u}: max |sorted difference| {difference.max():.3e} at rank {int(difference.argmax())+1}, L1 {difference.sum():.3e}, "
    f"relative to the rank-1 value {difference.max()/certified_u[0]:.1e}")
if top >= 4:
    layer4_sorted = {name: np.sort(np.array(list(values[name][4].values())))[::-1] for name in graphs}
    first_four = int(np.argmax(pooled["untwisted"] <= layer4_sorted["untwisted"][0])) + 1
    log(f"the largest four-defect outcome has rank {first_four} in the untwisted sorted readout "
        f"(K_3(40) = {sum(math.comb(n, k) for k in range(4))}): the three- and four-defect layers interleave at this angle")
    above = int((layer4_sorted["untwisted"] > P[5]).sum())
    segment = np.abs(layer4_sorted["untwisted"][:above] - layer4_sorted["twisted"][:above])
    log(f"the {above} four-defect values above P_5, sorted within the layer: max |difference| {segment.max():.3e}, L1 {segment.sum():.3e}")

# pointwise comparison with the shared labels
for layer_size in range(0, 4):
    differing = []
    for defect_set, p_u in values["untwisted"][layer_size].items():
        p_t = values["twisted"][layer_size][defect_set]
        if abs(p_u - p_t) > 1e-15 * max(p_u, p_t):
            differing.append((abs(p_u - p_t), defect_set, p_u, p_t))
    differing.sort(reverse=True)
    worst_text = f"; largest at defect set {differing[0][1]}: {differing[0][2]:.9e} vs {differing[0][3]:.9e}" if differing else ""
    log(f"pointwise, layer {layer_size}: outcomes differing above relative 1e-15: {len(differing)}{worst_text}")
    if layer_size == 2 and differing:
        touched = sorted(set(v for _, d, _, _ in differing for v in d))
        log(f"    vertices occurring in the differing two-defect sets: {touched}")
        u_sorted = sorted(r[2] for r in differing)
        t_sorted = sorted(r[3] for r in differing)
        log(f"    the differing two-defect values, sorted within each graph, agree to {max(abs(a-b) for a, b in zip(u_sorted, t_sorted)):.3e}")

# ----------------------------------------------------------------------------------------------------------------
# stage D: the modal outcome at high precision and an interval certificate
# ----------------------------------------------------------------------------------------------------------------
log("== Stage D: the modal outcome at high precision")
all_ones = [1] * n
for digits in (50, 80, 120):
    mpmath.mp.dps = digits
    mixer, prep, phase, one, zero = mp_constants()
    started = time.time()
    p = {name: abs(contract_amplitude_generic(graphs[name], orders[name], all_ones, mixer, prep, phase, one, zero)) ** 2 for name in graphs}
    log(f"dps={digits}: p_untwisted(1^40) = {mpmath.nstr(p['untwisted'], 32)}, difference untwisted - twisted = "
        f"{mpmath.nstr(p['untwisted'] - p['twisted'], 15)}  ({time.time()-started:.0f}s)")
mpmath.mp.dps = 50
mixer, prep, phase, one, zero = mp_constants()
for defect_set in [(18, 22), (0, 17), (0, 19)]:
    outcome_bits = [0 if v in defect_set else 1 for v in range(n)]
    p = {name: abs(contract_amplitude_generic(graphs[name], orders[name], outcome_bits, mixer, prep, phase, one, zero)) ** 2 for name in graphs}
    log(f"dps=50: defects {defect_set}: p_untwisted = {mpmath.nstr(p['untwisted'], 20)}, difference = {mpmath.nstr(p['untwisted'] - p['twisted'], 10)}")

mpmath.iv.dps = 60
mixer, prep, phase, one, zero = iv_constants()
started = time.time()
enclosures = {name: contract_amplitude_generic(graphs[name], orders[name], all_ones, mixer, prep, phase, one, zero).modulus_squared() for name in graphs}
difference = enclosures["untwisted"] - enclosures["twisted"]
log(f"interval arithmetic at 60 digits ({time.time()-started:.0f}s):")
for name, enclosure in enclosures.items():
    log(f"  p_{name}(1^40) in [{mpmath.nstr(enclosure.a, 25)}, {mpmath.nstr(enclosure.b, 25)}], width {mpmath.nstr(enclosure.delta, 3)}")
log(f"  p_untwisted - p_twisted in [{mpmath.nstr(difference.a, 15)}, {mpmath.nstr(difference.b, 15)}]; excludes zero: {difference.a > 0 or difference.b < 0}")
log("done")
