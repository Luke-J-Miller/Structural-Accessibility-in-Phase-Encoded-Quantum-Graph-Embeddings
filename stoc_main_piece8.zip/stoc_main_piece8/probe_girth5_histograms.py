"""The two- and three-defect (E_in, E_out) histograms of cubic graphs of girth at least five.

Checks, against exhaustive enumeration of the subsets, the closed forms of the theorem on girth at least five:
  two defects:   (0, n-6): 3n/2,  (2, n-7): 3n,  (2, n-8): C(n,2) - 9n/2;
  three defects: (0, n-8): 3n,
                 (1, n-10): 3n(n-14)/2 + 5 C5,  (1, n-9): 12n - 10 C5,  (1, n-8): 5 C5,
                 (3, n-12): C(n,3) - 9n^2/2 + 41n - 5 C5 - 2 C6,  (3, n-11): 3n^2 - 48n + 10 C5 + 6 C6,
                 (3, n-10): 12n - 5 C5 - 6 C6,  (3, n-9): n + 2 C6;
and the two odd-reading entries read by the Y mixer: triples with one internal edge and outside odd readings
(-(n-8), -1) number 5 C5, independent triples with outside odd readings (-(n-9), 0) number 2 C6.
Populations: every connected cubic graph of girth at least five in the nauty-geng censuses at n = 10, 12, 14, 16, 18,
random connected cubic graphs of girth five and of girth at least seven up to n = 40, and, for the statement that the
first K_3(n) ranks determine min(girth, 7), every graph of the censuses at n = 10, 12, 14, 16 grouped by
(pair census, three-defect histogram)."""
import itertools
import subprocess
import time
from math import comb
import numpy as np
import networkx as nx


def profile_histograms(adjacency, layer_size):
    """Histogram over layer_size-subsets of (E_in, E_out), and of (e, odd outside readings) for the Y check."""
    n = adjacency.shape[0]
    extremal, odd = {}, {}
    for defect_set in itertools.combinations(range(n), layer_size):
        defect_list = list(defect_set)
        counts = adjacency[:, defect_list].sum(axis=1)
        inside = counts[defect_list]
        mask = np.ones(n, dtype=bool)
        mask[defect_list] = False
        outside = counts[mask]
        q_in = [int((inside == k).sum()) for k in range(4)]
        q_out = [int((outside == k).sum()) for k in range(4)]
        key = (q_in[0] + q_in[3], q_out[0] + q_out[3])
        extremal[key] = extremal.get(key, 0) + 1
        internal_edges = int(inside.sum()) // 2
        odd_key = (internal_edges, q_out[3] - q_out[0], q_out[2] - q_out[1])
        odd[odd_key] = odd.get(odd_key, 0) + 1
    return extremal, odd


def pair_census(adjacency):
    n = adjacency.shape[0]
    common = adjacency @ adjacency
    census = {}
    for u in range(n):
        for v in range(u + 1, n):
            key = (int(adjacency[u, v]), int(common[u, v]))
            census[key] = census.get(key, 0) + 1
    return tuple(sorted(census.items()))


def cycle_counts(graph):
    counts = {5: 0, 6: 0}
    for cycle in nx.simple_cycles(graph, length_bound=6):
        if len(cycle) in counts:
            counts[len(cycle)] += 1
    return counts[5], counts[6]


def predicted_two(n):
    table = {(0, n - 6): 3 * n // 2, (2, n - 7): 3 * n, (2, n - 8): comb(n, 2) - 9 * n // 2}
    return {k: v for k, v in table.items() if v != 0}


def predicted_three(n, c5, c6):
    table = {
        (0, n - 8): 3 * n,
        (1, n - 10): 3 * n * (n - 14) // 2 + 5 * c5,
        (1, n - 9): 12 * n - 10 * c5,
        (1, n - 8): 5 * c5,
        (3, n - 12): comb(n, 3) - 9 * n * n // 2 + 41 * n - 5 * c5 - 2 * c6,
        (3, n - 11): 3 * n * n - 48 * n + 10 * c5 + 6 * c6,
        (3, n - 10): 12 * n - 5 * c5 - 6 * c6,
        (3, n - 9): n + 2 * c6,
    }
    return {k: v for k, v in table.items() if v != 0}


def check_graph(graph):
    adjacency = nx.to_numpy_array(graph, dtype=np.int64)
    n = adjacency.shape[0]
    c5, c6 = cycle_counts(graph)
    two, _ = profile_histograms(adjacency, 2)
    three, odd = profile_histograms(adjacency, 3)
    ok_two = two == predicted_two(n)
    ok_three = three == predicted_three(n, c5, c6)
    ok_y = odd.get((1, -(n - 8), -1), 0) == 5 * c5 and odd.get((0, -(n - 9), 0), 0) == 2 * c6
    return n, c5, c6, ok_two, ok_three, ok_y, three


def census(n):
    lines = subprocess.run(["nauty-geng", "-c", "-d3", "-D3", "-q", str(n)], capture_output=True, text=True).stdout.split()
    return [nx.from_graph6_bytes(line.encode()) for line in lines]


started = time.time()
print("== census graphs of girth at least five")
total_checked = 0
for n in (10, 12, 14, 16, 18):
    graphs = census(n)
    girth5 = [g for g in graphs if nx.girth(g) >= 5]
    failures = 0
    girths = {}
    for g in girth5:
        _, c5, c6, ok_two, ok_three, ok_y, _ = check_graph(g)
        failures += not (ok_two and ok_three and ok_y)
        girths[nx.girth(g)] = girths.get(nx.girth(g), 0) + 1
    total_checked += len(girth5)
    print(f"n={n}: {len(graphs)} connected cubic graphs, {len(girth5)} of girth >= 5 (by girth: {dict(sorted(girths.items()))}); "
          f"closed forms fail on {failures} of them  ({time.time()-started:.0f}s)")

print("== random connected cubic graphs of girth five and of girth at least seven")
rng = np.random.default_rng(1)
mcgee = nx.LCF_graph(24, [12, 7, -7], 8)                    # the (3,7)-cage
tutte_coxeter = nx.LCF_graph(30, [-13, -9, 7, -7, 9, 13], 5)  # the (3,8)-cage
assert nx.girth(mcgee) == 7 and nx.girth(tutte_coxeter) == 8
found = {5: [], 7: [mcgee, tutte_coxeter]}
tries = 0
while (len(found[5]) < 25 or len(found[7]) < 8) and tries < 150000:
    tries += 1
    n = int(rng.choice([20, 22, 24, 26, 28, 30, 32, 36, 40]))
    g = nx.random_regular_graph(3, n, seed=int(rng.integers(0, 2 ** 31)))
    if not nx.is_connected(g):
        continue
    girth = nx.girth(g)
    if girth >= 7 and len(found[7]) < 8:
        found[7].append(g)
    elif girth == 5 and len(found[5]) < 25:
        found[5].append(g)
print(f"random search: {tries} tries")
for label, graphs in (("girth 5", found[5]), ("girth >= 7", found[7])):
    failures = 0
    orders = {}
    histograms_by_order = {}
    for g in graphs:
        n, c5, c6, ok_two, ok_three, ok_y, three = check_graph(g)
        failures += not (ok_two and ok_three and ok_y)
        orders[n] = orders.get(n, 0) + 1
        histograms_by_order.setdefault(n, set()).add(tuple(sorted(three.items())))
    print(f"{label}: {len(graphs)} graphs, orders {dict(sorted(orders.items()))}; closed forms fail on {failures}")
    if label == "girth >= 7":
        print(f"   girth >= 7: distinct three-defect histograms per order: {dict(sorted((n, len(s)) for n, s in histograms_by_order.items()))} "
              f"(the closed form with C5 = C6 = 0 depends on n alone)")
        print(f"   girths of the girth >= 7 sample: {sorted(nx.girth(g) for g in graphs)}")

print("== min(girth, 7) from the pair census and the three-defect histogram, whole censuses")
for n in (10, 12, 14, 16):
    graphs = census(n)
    groups = {}
    for g in graphs:
        adjacency = nx.to_numpy_array(g, dtype=np.int64)
        three, _ = profile_histograms(adjacency, 3)
        key = (pair_census(adjacency), tuple(sorted(three.items())))
        groups.setdefault(key, set()).add(min(nx.girth(g), 7))
    violations = sum(1 for s in groups.values() if len(s) > 1)
    print(f"n={n}: {len(graphs)} graphs, {len(groups)} classes of (pair census, three-defect histogram), "
          f"classes with more than one value of min(girth,7): {violations}  ({time.time()-started:.0f}s)")
print(f"total girth >= 5 census graphs checked: {total_checked}; done in {time.time()-started:.0f}s")
