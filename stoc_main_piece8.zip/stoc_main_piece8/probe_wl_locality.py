"""Numerical check of the order-j locality proposition and its WL corollary (r = 1, X and Y mixers).

Claim 1 (locality).  For every cubic G on n vertices and every outcome x with defect set D,
    [beta^j] p_G(x;beta)/mu(x)  =  sum_{T subset V\\D, |T|<=j}  g_j(pattern(D,T)),
with g_j depending on n, the member and the angles but not on G.  Checked by fitting one linear
function of the pattern counts across all (G, D) of the complete census at fixed n and reporting
the largest residual (should be at rounding level).

Claim 2 (WL).  The round-j colour of the padded tuple (d_1..d_m, d_m, ..., d_m) in V^{m+j} under
folklore (m+j)-WL determines the vector of coefficients up to order j.  Checked by refining
jointly over all graphs of the census and asserting that tuples with equal colour have equal
coefficient vectors.  Also checked: one round of max(m,2)-WL on the unpadded tuple determines
the first-order coefficient.
"""
import itertools, sys, math
from collections import defaultdict
import numpy as np
import networkx as nx
sys.path.insert(0, "/tmp/claude-0/-home-claude/3765afd1-58aa-54a7-93e0-43428d2ed9fe/scratchpad")
from scratch_theoremA_check import complete_cubic_census_by_sampling

ETA, GAMMA = 23 / 8, 2.0
c, s = math.cos(ETA / 2), math.sin(ETA / 2)


def prepared_amplitude(A):
    """phi(x) = prod_v a(x_v) * exp(-i gamma/2 sum_{uv in E} z_u z_v), little-endian bit order."""
    n = A.shape[0]
    N = 1 << n
    xs = np.arange(N)
    bits = ((xs[:, None] >> np.arange(n)[None, :]) & 1)        # bits[x, v]
    z = 1 - 2 * bits                                             # +1 for x_v = 0 (defect), -1 for x_v = 1
    a = np.where(bits == 0, c, -1j * s)
    prep = np.prod(a, axis=1)
    iu = np.triu_indices(n, 1)
    edge_mask = A[iu] == 1
    zz = (z[:, iu[0]] * z[:, iu[1]])[:, edge_mask].sum(axis=1)
    phase = np.exp(-0.5j * GAMMA * zz)
    return prep * phase, bits, z


def apply_generator(chi, bits, z, mixer):
    """(Sigma chi)(x) for Sigma = sum_v X_v or sum_v Y_v; (Y_v chi)(x) = -i z_v(x) chi(x xor e_v)."""
    n = bits.shape[1]
    N = chi.shape[0]
    xs = np.arange(N)
    out = np.zeros(N, dtype=complex)
    for v in range(n):
        flipped = chi[xs ^ (1 << v)]
        if mixer == "X":
            out += flipped
        else:
            out += -1j * z[:, v] * flipped
    return out


def taylor_coefficients(A, mixer, jmax):
    """p_j(x) = [beta^j] p(x;beta) for r = 1, from psi_k = (-i Sigma/2)^k phi."""
    phi, bits, z = prepared_amplitude(A)
    psis = [phi]
    for k in range(1, jmax + 1):
        psis.append((-0.5j) * apply_generator(psis[-1], bits, z, mixer))
    coeffs = []
    for j in range(jmax + 1):
        pj = np.zeros(phi.shape[0], dtype=complex)
        for a in range(j + 1):
            b = j - a
            pj += np.conj(psis[a]) * psis[b] / (math.factorial(a) * math.factorial(b))
        assert np.abs(pj.imag).max() < 1e-12
        coeffs.append(pj.real)
    mu = np.abs(phi) ** 2
    return coeffs, mu, bits


def pattern_key(A, D, T):
    """Canonical key of the marked graph (G[D u T]; D, T): minimum adjacency string over class-preserving relabellings."""
    best = None
    for pD in itertools.permutations(D):
        for pT in itertools.permutations(T):
            order = list(pD) + list(pT)
            key = tuple(int(A[order[i], order[k]]) for i in range(len(order)) for k in range(i + 1, len(order)))
            if best is None or key < best:
                best = key
    return (len(D), len(T), best)


def pattern_counts(A, D, jmax):
    n = A.shape[0]
    outside = [v for v in range(n) if v not in D]
    counts = defaultdict(int)
    for size in range(jmax + 1):
        for T in itertools.combinations(outside, size):
            counts[pattern_key(A, D, T)] += 1
    return counts


def check_locality(graphs, m, j, mixer):
    rows, targets = [], []
    for G in graphs:
        A = nx.to_numpy_array(G, dtype=int)
        n = A.shape[0]
        coeffs, mu, bits = taylor_coefficients(A, mixer, j)
        for D in itertools.combinations(range(n), m):
            x = sum(1 << v for v in range(n) if v not in D)      # defects are the zero bits
            assert set(np.flatnonzero(bits[x] == 0)) == set(D)
            rows.append(pattern_counts(A, D, j))
            targets.append(coeffs[j][x] / mu[x])
    keys = sorted({k for r in rows for k in r}, key=str)
    X = np.array([[r.get(k, 0) for k in keys] for r in rows], dtype=float)
    y = np.array(targets)
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = np.abs(X @ coef - y).max()
    spread = y.max() - y.min()
    return len(rows), len(keys), np.linalg.matrix_rank(X), resid, spread


def folklore_wl_colours(graphs, k, rounds):
    """Folklore k-WL colours of all k-tuples of every graph, refined jointly (shared colour dictionary).
    Returns a list (per graph) of dicts tuple -> colour id after `rounds` rounds."""
    palette = {}

    def cid(obj):
        if obj not in palette:
            palette[obj] = len(palette)
        return palette[obj]

    per_graph = []
    for G in graphs:
        A = nx.to_numpy_array(G, dtype=int)
        n = A.shape[0]
        col = {}
        for u in itertools.product(range(n), repeat=k):
            atomic = tuple((int(u[i] == u[l]), int(A[u[i], u[l]])) for i in range(k) for l in range(i + 1, k))
            col[u] = cid(("atomic", atomic))
        per_graph.append((A, n, col))
    for _ in range(rounds):
        new_per_graph = []
        for A, n, col in per_graph:
            new = {}
            for u in col:
                ms = []
                for w in range(n):
                    ms.append(tuple(col[u[:i] + (w,) + u[i + 1:]] for i in range(k)))
                ms.sort()
                new[u] = cid((col[u], tuple(ms)))
            new_per_graph.append((A, n, new))
        per_graph = new_per_graph
    return [col for _, _, col in per_graph]


def check_wl(graphs, m, j, mixer, k, rounds, pad):
    """Equal colour of the (padded) defect tuple  =>  equal coefficient vector up to order j."""
    cols = folklore_wl_colours(graphs, k, rounds)
    seen = {}
    violations = 0
    classes = 0
    for G, col in zip(graphs, cols):
        A = nx.to_numpy_array(G, dtype=int)
        n = A.shape[0]
        coeffs, mu, bits = taylor_coefficients(A, mixer, j)
        for D in itertools.permutations(range(n), m):
            x = sum(1 << v for v in range(n) if v not in D)
            tup = tuple(D) + (D[-1],) * (k - m) if pad else tuple(D)
            assert len(tup) == k
            vec = tuple(round(coeffs[jj][x] / mu[x], 9) for jj in range(j + 1))
            colour = col[tup]
            if colour in seen:
                if seen[colour] != vec:
                    violations += 1
            else:
                seen[colour] = vec
                classes += 1
    return classes, violations


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    count = {10: 19, 12: 85}[n]
    graphs = complete_cubic_census_by_sampling(n, count)
    print(f"census n={n}: {len(graphs)} graphs")
    for mixer in ("X", "Y"):
        for (m, j) in ((2, 1), (2, 2), (3, 1), (3, 2), (1, 2), (1, 3), (2, 3)):
            if n == 12 and (m, j) in ((2, 3), (3, 2)):
                continue
            rows, keys, rank, resid, spread = check_locality(graphs, m, j, mixer)
            print(f"locality  mixer={mixer} m={m} j={j}: rows {rows}, patterns {keys}, rank {rank}, "
                  f"max residual {resid:.2e}, target spread {spread:.3f}")
    if n == 10:
        for mixer in ("X", "Y"):
            for (m, j, k, rounds, pad) in ((2, 1, 2, 1, False), (3, 1, 3, 1, False), (1, 2, 3, 2, True),
                                           (2, 2, 4, 2, True), (3, 1, 4, 1, True)):
                classes, violations = check_wl(graphs, m, j, mixer, k, rounds, pad)
                print(f"WL  mixer={mixer} m={m} j={j} k={k} rounds={rounds} pad={pad}: "
                      f"{classes} colour classes, {violations} violations")
