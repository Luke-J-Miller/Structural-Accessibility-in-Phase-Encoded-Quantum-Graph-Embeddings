"""The modal difference of the CFI pair over K4 at halved mixer angles, and the tail mass and L1 bound of the run of record.

Companion to probe_cfi_operating_angle.py (the run of record for the appendix on the pair over K4); it reuses that
script's construction and exact-contraction code and reads the pooled outcome arrays it saved
(cfi_k4_pooled_untwisted.npy, cfi_k4_pooled_twisted.npy, next to this file).  Two computations:
  1. p_untwisted(1^40; beta) - p_twisted(1^40; beta) at beta = 1/10, 1/20, 1/40, 1/80 by exact contraction of the
     two-state partition function in 90 decimal digits (mpmath), with (eta, gamma) = (23/8, 2) fixed; the log2 of the
     ratio of successive differences estimates the order of the first nonzero Taylor coefficient of the modal
     difference (Theorem wl(2) guarantees agreement through the second order only).
  2. From the saved pooled arrays (every outcome with at most four defects, sorted): the computed probability mass,
     the mass of the uncomputed tail (five or more defects), the L1 distance between the two sorted computed parts,
     and the bound L1_computed + tail_untwisted + tail_twisted on the L1 distance between the two full sorted readouts
     (Proposition w1: the sorted L1 distance is the minimum over pairings, and pairing computed with computed in sorted
     order and tail with tail gives this bound).
Usage: python3 probe_cfi_modal_scaling.py"""
import math
import os
import time

import mpmath
import networkx as nx
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

# definitions (construction, elimination order, generic contraction) from the run of record; the marker splits the
# definitions from the stages that run on import
with open(os.path.join(HERE, "probe_cfi_operating_angle.py")) as handle:
    source = handle.read()
marker = "# stage B: pairs, refinement, first-order histograms"
assert source.count(marker) == 1
definitions = source[: source.index(marker)].rsplit("\n# ---", 1)[0]
namespace = {}
exec(compile(definitions, "probe_cfi_operating_angle.py[definitions]", "exec"), namespace)
cfi_pair = namespace["cfi_pair"]
elimination_order = namespace["elimination_order"]
contract_amplitude_generic = namespace["contract_amplitude_generic"]


def log(message):
    print(message, flush=True)


def mp_constants_at(beta):
    """Gate entries of PE-X1 at (eta, gamma) = (23/8, 2) and mixer angle beta, as mpmath complex numbers."""
    eta, gamma = mpmath.mpf(23) / 8, mpmath.mpf(2)
    I = mpmath.mpc(0, 1)
    ce, se = mpmath.cos(eta / 2), mpmath.sin(eta / 2)
    cb, sb = mpmath.cos(beta / 2), mpmath.sin(beta / 2)
    mixer = {(0, 0): mpmath.mpc(cb), (1, 1): mpmath.mpc(cb), (0, 1): -I * sb, (1, 0): -I * sb}
    prep = {0: mpmath.mpc(ce), 1: -I * se}
    phase = {(0, 0): mpmath.exp(-I * gamma / 2), (1, 1): mpmath.exp(-I * gamma / 2),
             (0, 1): mpmath.exp(I * gamma / 2), (1, 0): mpmath.exp(I * gamma / 2)}
    return mixer, prep, phase, mpmath.mpc(1), mpmath.mpc(0)


# the pair over K4 with the labelling of the run of record
base = nx.convert_node_labels_to_integers(nx.complete_graph(4))
untwisted, twisted = cfi_pair(base)
labels = {node: i for i, node in enumerate(untwisted.nodes())}
graphs = {"untwisted": nx.relabel_nodes(untwisted, labels), "twisted": nx.relabel_nodes(twisted, labels)}
n = graphs["untwisted"].number_of_nodes()
assert n == 40 and not nx.is_isomorphic(graphs["untwisted"], graphs["twisted"])
orders = {name: elimination_order(graph)[0] for name, graph in graphs.items()}
all_ones = [1] * n

# 1. the modal difference at halved angles
log("== Modal difference p_untwisted(1^40) - p_twisted(1^40) at (eta, gamma) = (23/8, 2), 90 decimal digits")
mpmath.mp.dps = 90
betas = [mpmath.mpf(1) / 10, mpmath.mpf(1) / 20, mpmath.mpf(1) / 40, mpmath.mpf(1) / 80]
differences = []
for beta in betas:
    started = time.time()
    mixer, prep, phase, one, zero = mp_constants_at(beta)
    p = {name: abs(contract_amplitude_generic(graphs[name], orders[name], all_ones, mixer, prep, phase, one, zero)) ** 2
         for name in graphs}
    difference = p["untwisted"] - p["twisted"]
    differences.append(difference)
    log(f"beta = {mpmath.nstr(beta, 6)}: p_untwisted(1^40) = {mpmath.nstr(p['untwisted'], 25)}, "
        f"difference = {mpmath.nstr(difference, 15)}  ({time.time()-started:.0f}s)")
log("ratios of successive differences (beta halved each step), as log2:")
for previous, current in zip(differences, differences[1:]):
    log(f"  log2(difference(beta) / difference(beta/2)) = {mpmath.nstr(mpmath.log(previous / current, 2), 6)}")
log("a modal difference whose first nonzero Taylor coefficient is beta^k scales as 2^k per halving; the fitted exponent is "
    f"{mpmath.nstr(mpmath.log(differences[0] / differences[-1], 2) / 3, 5)} over the three halvings")

# 2. the tail mass and the L1 bound from the saved outcomes of the run of record
log("== Tail mass and L1 bound from the pooled outcome arrays of probe_cfi_operating_angle.py")
pooled = {name: np.load(os.path.join(HERE, f"cfi_k4_pooled_{name}.npy")) for name in graphs}
expected = sum(math.comb(n, k) for k in range(5))
for name, values in pooled.items():
    assert values.shape == (expected,), values.shape
    assert np.all(np.diff(values) <= 0)
mass = {name: float(values.sum()) for name, values in pooled.items()}
tail = {name: 1.0 - mass[name] for name in graphs}
l1_computed = float(np.abs(pooled["untwisted"] - pooled["twisted"]).sum())
max_computed = float(np.abs(pooled["untwisted"] - pooled["twisted"]).max())
bound = l1_computed + tail["untwisted"] + tail["twisted"]
log(f"outcomes with at most four defects per graph: {expected}")
for name in graphs:
    log(f"  {name}: computed mass {mass[name]:.10f}, uncomputed tail (five or more defects) {tail[name]:.4e}")
log(f"L1 distance between the sorted computed parts: {l1_computed:.3e} (largest entry difference {max_computed:.3e})")
log(f"bound on the L1 distance between the two full sorted readouts, L1_computed + tail_untwisted + tail_twisted: {bound:.3e}")
log("done")
