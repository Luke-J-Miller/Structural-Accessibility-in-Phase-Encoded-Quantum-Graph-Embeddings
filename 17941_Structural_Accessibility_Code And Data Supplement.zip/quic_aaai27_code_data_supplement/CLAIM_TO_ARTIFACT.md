# Claim-to-Artifact Index

This document maps the paper’s principal theoretical and empirical results to the notebooks, inputs, and run-of-record outputs included in the archive.

## Formal Results

| Paper result | Notebook | Required inputs | Recorded output |
|---|---|---|---|
| Cut-phase and boundary-transform identities | `EF3_formalism_reproducible_calculations.ipynb` | Circuit parameters defined in notebook | `results/formalism/formalism_reproducible_calculations.json` or retained notebook output |
| Quantile interpretation of sorted probabilities | `EF3_formalism_reproducible_calculations.ipynb` | Probability-vector checks defined in notebook | Same as above |
| Defect layers and pair-incidence census | `EF3_formalism_reproducible_calculations.ipynb` | Small cubic graph fixtures defined in notebook | Same as above |
| PE-X1 second-purity closure | `EF7_purity_proofs.ipynb` | Canonical preparation and phase parameters | `results/formalism/purity_kernel_symbolic_certificate.json` |
| Nonzero PE-X1 motif coefficients | `EF1_finite_angle_head_certificate.ipynb` | Canonical parameters and graph orders | `results/formalism/coefficient_certificate_results.json` |
| PE-QX1/Hadamard purity closure | `EF8_phase_general_purity_closure.ipynb`; `EF11v2_hadamard_closure_census.ipynb` | Hadamard preparation and cubic census data | `results/formalism/phase_general_purity_closure_results.json`; `results/formalism/hadamard_closure_census_results.json` |
| Finite-angle low-defect head certificate | `EF1_finite_angle_head_certificate.ipynb`; `EF4_head_reduction_proof.ipynb` | Canonical parameters and graph orders | `results/formalism/finite_angle_head_certificate_results.json` |
| Finite-angle continuation of the purity tangent | `EF20_finite_angle_continuation_audit.ipynb` | `data/populations/cubic_n14.g6`; circuit definitions | `results/formalism/finite_angle_continuation_summary.json`; `results/formalism/finite_angle_continuation_graph_values.csv` |
| Cubic spectral moment identities | `EF3_trace_identity_proof.ipynb` | Exact graph fixtures | Retained notebook output |

## Populations, Targets, and Circuits

| Paper result | Notebook | Required inputs | Recorded output |
|---|---|---|---|
| Cubic \(n=14\), cubic \(n=16\), 4-regular \(n=12\), and cubic \(n=18\) populations | `EX1_population_targets_folds.ipynb` | nauty/Traces | `data/populations/*.g6`; `results/family/EX1_population_manifest.json` |
| Structural target definitions | `EX1_population_targets_folds.ipynb` | Frozen graph populations | `data/targets/EX1_targets.csv` |
| Held-out fold assignments | `EX1_population_targets_folds.ipynb` | Frozen populations and recorded seed | `data/folds/EX1_folds.json` |
| Four phase-encoded circuit arms and frozen schedule | `EX2_circuit_factory.ipynb` | Frozen graph populations | `results/family/EX2_circuit_manifest.json` |

## Exact-State Family Characterization

| Paper result | Notebook | Required inputs | Recorded output |
|---|---|---|---|
| Exact-state accessibility on the complete cubic \(n=14\) census | `EX3_family_screen.ipynb` | `cubic_n14.g6`; targets; folds; circuit manifest | `results/family/EX3_family_screen.json` |
| Collision audit on cubic \(n=14\) | `EX3_family_screen.ipynb` | Same as above | Diagnostic fields in `EX3_family_screen.json` |
| Evaluation on the complete 4-regular \(n=12\) census | `EX4A_regular_census.ipynb` | `regular4_n12.g6`; targets; folds; circuit manifest | `results/family/EX4A_regime_transfer.json` |
| Collision audit on 4-regular \(n=12\) | `EX4A_regular_census.ipynb` | Same as above | Diagnostic fields in `EX4A_regime_transfer.json` |
| Blindness and mechanism controls | `EX5_mechanism_controls.ipynb` | Cubic \(n=14\) population; targets; folds; circuit definitions | `results/family/EX5_mechanism_controls.json` |
| Angle-transect analysis | `EX7_angle_transect.ipynb` | Cubic \(n=14\) population; targets; circuit definitions | `results/family/EX7_angle_transect.json` |
| Precision, solver, and simulator robustness | `EX11_robustness_audit.ipynb` | Circuit definitions and selected graph fixtures | `results/family/EX11_robustness_audit.json` |

## Geometry and Rank Localization

| Paper result | Notebook | Required inputs | Recorded output |
|---|---|---|---|
| Global and stratified representation geometry | `EX13P_geometry_producer.ipynb`; `EX13E_geometry_synthesis.ipynb` | Frozen populations; targets; circuit vectors; frozen strata | `results/geometry/EX13P_producer_manifest.json`; `EX13P_strata.json`; `EX13E_synthesis.json` |
| Rank localization of structural channels | `EX6_rank_localization.ipynb` | Cubic \(n=14\) circuit vectors; targets; folds | `results/rank_localization/EX6_rank_localization.json` |
| Retained probability mass by head length | `EX6_rank_localization.ipynb` | Same as above | Retained-mass fields in `EX6_rank_localization.json` |

## Irregular Fixed-Degree Strata

| Paper result | Notebook | Required inputs | Recorded output |
|---|---|---|---|
| Construction of fixed-degree irregular strata | `EX4C_irregular_bucket_freeze.ipynb` | Irregular graph candidate population | `data/intermediate/EX4C_bucket_freeze.json`; generated pickle checkpoint omitted from the compact archive |
| Accessibility on fixed-degree irregular strata | `EX4B_irregular_stratum_analysis.ipynb` | Pickle checkpoint generated by `EX4C_irregular_bucket_freeze.ipynb`; circuit definitions | `results/family/EX4B_stratum_analysis.json` |

## Classical Placement and Witnesses

| Paper result | Notebook | Required inputs | Recorded output |
|---|---|---|---|
| Spectral, Extra Trees, and folklore 2-WL controls | `EX9A_classical_placement.ipynb` | Frozen populations; targets; folds | `results/classical_controls/EX9A_classical_placement.json` |
| Construction of cubic \(n=18\) cospectral witness classes | `EX9W_witness_producer.ipynb` | `data/populations/cubic_n18.g6` | `results/witnesses/EX9W_witness_manifest.json` |
| Separation and ranking of six \(K_4-e\)-varying cospectral pairs | `EX9B_witness_audit.ipynb` | Witness manifest; frozen circuit vectors | `results/witnesses/EX9B_witness_audit.json` |

## Finite-Shot Accessibility

| Paper result | Notebook | Required inputs | Recorded output |
|---|---|---|---|
| Finite-shot recovery under globally sorted readout | `EX8_finite_shots.ipynb` | Exact circuit probabilities; targets; folds | `results/finite_shots/EX8_finite_shots.json` |
| Exact ceilings and replicate distributions | `EX8_finite_shots.ipynb` | Same as above | Exact-ceiling and replicate fields in `EX8_finite_shots.json` |

## Structured Readout

| Paper result | Notebook | Required inputs | Recorded output |
|---|---|---|---|
| Irregular graph and target production | `E6D_irregular_data_producer.ipynb` | Irregular fixed-degree graph strata | Generated `n14_e6d_data_dict.pkl`; omitted from the compact archive |
| Analytical joint-degree mixing basis | `E30_mixing_basis_producer.ipynb` | Frozen irregular population | Generated `e30_analytical_mixing_basis.pkl`; omitted from the compact archive |
| Worker calculations for Sort, Hamming-weight pooling, and degree-sector aggregation | `e29f-hx-s1.ipynb`; `e29f-hx-s2.ipynb`; `e29f-hx-s3.ipynb` | Checkpoints generated by `E6D_irregular_data_producer.ipynb` and `E30_mixing_basis_producer.ipynb` | Generated worker pickle checkpoints; omitted from the compact archive |
| Structured-readout finite-shot synthesis | `e29f-hx-synthesis.ipynb` | Worker checkpoints generated by the three worker notebooks | `results/structured_readout/e29f_hx_mixing_summary.csv`; `results/structured_readout/e29f_hx_paired_readout_differences.csv` |

## Notebook Inventory

Every notebook listed above retains:

- the scientific code used for the corresponding calculation;
- relative paths to its required inputs;
- the output filename written by the completed run.

Embedded outputs are removed except for the compact trace-identity proof output. The included JSON, CSV, and graph6 files are the compact run-of-record artifacts used by the paper. Large pickle checkpoints are explicitly identified above and can be regenerated from the included producer and worker code.
