# Code and Data Supplement

This archive contains the notebooks, frozen inputs, and run-of-record outputs supporting the paper.

The work was developed primarily in hosted Jupyter/Kaggle environments. The archive reproduces the required file relationships in a conventional local directory structure. Notebook paths assume that the working directory is `notebooks/` and therefore use paths such as:

```python
population_path = "../data/populations/cubic_n14.g6"
result_path = "../results/family/EX3_family_screen.json"
```

The notebooks are provided for inspection and reproduction. To meet the conference upload limit, embedded notebook outputs and regenerable pickle checkpoints are omitted. The compact JSON and CSV files in `results/` are the run-of-record records used for the paper. Some complete-census, statevector, interval-arithmetic, and finite-shot calculations are computationally expensive.

## Directory Structure

```text
.
├── README.md
├── CLAIM_TO_ARTIFACT.md
├── notebooks/
│   ├── EF1_finite_angle_head_certificate.ipynb
│   ├── EF3_formalism_reproducible_calculations.ipynb
│   ├── EF3_trace_identity_proof.ipynb
│   ├── EF4_head_reduction_proof.ipynb
│   ├── EF7_purity_proofs.ipynb
│   ├── EF8_phase_general_purity_closure.ipynb
│   ├── EF11v2_hadamard_closure_census.ipynb
│   ├── EF20_finite_angle_continuation_audit.ipynb
│   ├── EX1_population_targets_folds.ipynb
│   ├── EX2_circuit_factory.ipynb
│   ├── EX3_family_screen.ipynb
│   ├── EX4A_regular_census.ipynb
│   ├── EX4B_irregular_stratum_analysis.ipynb
│   ├── EX4C_irregular_bucket_freeze.ipynb
│   ├── EX5_mechanism_controls.ipynb
│   ├── EX6_rank_localization.ipynb
│   ├── EX7_angle_transect.ipynb
│   ├── EX8_finite_shots.ipynb
│   ├── EX9A_classical_placement.ipynb
│   ├── EX9B_witness_audit.ipynb
│   ├── EX9W_witness_producer.ipynb
│   ├── EX11_robustness_audit.ipynb
│   ├── EX13P_geometry_producer.ipynb
│   ├── EX13A_geometry_cubic14.ipynb
│   ├── EX13B_geometry_regular4_n12.ipynb
│   ├── EX13C_geometry_cubic16_stratified.ipynb
│   ├── EX13D_geometry_cubic16_global.ipynb
│   ├── EX13E_geometry_synthesis.ipynb
│   ├── E6D_irregular_data_producer.ipynb
│   ├── E30_mixing_basis_producer.ipynb
│   ├── e29f-hx-s1.ipynb
│   ├── e29f-hx-s2.ipynb
│   ├── e29f-hx-s3.ipynb
│   └── e29f-hx-synthesis.ipynb
├── data/
│   ├── populations/
│   │   ├── heterogeneous_n8.g6
│   │   ├── cubic_n14.g6
│   │   ├── cubic_n16.g6
│   │   ├── cubic_n18.g6
│   │   └── regular4_n12.g6
│   ├── targets/
│   │   └── EX1_targets.csv
│   ├── folds/
│   │   └── EX1_folds.json
│   └── intermediate/
│       └── EX4C_bucket_freeze.json
└── results/
    ├── formalism/
    │   ├── formalism_reproducible_calculations.json
    │   ├── purity_kernel_symbolic_certificate.json
    │   ├── coefficient_certificate_results.json
    │   ├── finite_angle_head_certificate_results.json
    │   ├── hadamard_closure_census_results.json
    │   ├── phase_general_purity_closure_results.json
    │   ├── finite_angle_continuation_summary.json
    │   └── finite_angle_continuation_graph_values.csv
    ├── family/
    │   ├── EX1_population_manifest.json
    │   ├── EX2_circuit_manifest.json
    │   ├── EX3_family_screen.json
    │   ├── EX4A_regime_transfer.json
    │   ├── EX4B_stratum_analysis.json
    │   ├── EX5_mechanism_controls.json
    │   ├── EX7_angle_transect.json
    │   └── EX11_robustness_audit.json
    ├── geometry/
    │   ├── EX13P_producer_manifest.json
    │   ├── EX13P_strata.json
    │   └── EX13E_synthesis.json
    ├── rank_localization/
    │   └── EX6_rank_localization.json
    ├── classical_controls/
    │   └── EX9A_classical_placement.json
    ├── witnesses/
    │   ├── EX9W_witness_manifest.json
    │   └── EX9B_witness_audit.json
    ├── finite_shots/
    │   └── EX8_finite_shots.json
    └── structured_readout/
        ├── e29f_hx_mixing_summary.csv
        └── e29f_hx_paired_readout_differences.csv
```

## Environment

The experiments were executed in hosted Kaggle CPU notebook environments. GPU acceleration was not used. The available CPU model varied across hosted sessions, and the paper makes no runtime or hardware-performance claims.

Principal observed software versions were:

- Python 3.12.13
- NumPy 2.0.2
- NetworkX 3.6.1
- scikit-learn 1.6.1
- Qiskit 2.5.1
- nauty/Traces 2.7001

Minor environment adjustments may be required outside Kaggle.

## Contents

### `notebooks/`

Contains the final notebooks used for graph-population construction, circuit simulation, formal calculations, exact-state characterization, classical controls, finite-shot experiments, and structured-readout experiments. Scientific code cells are retained. Embedded outputs are removed to meet the upload limit, except for the compact trace-identity proof output, which has no separate result file.

### `data/`

Contains the frozen graph populations, structural targets, fold assignments, and the compact irregular-stratum freeze record. Large pickle checkpoints are omitted and can be regenerated by the corresponding producer and worker notebooks.

### `results/`

Contains the final compact JSON and CSV records used to produce the reported values.

## Reproducing Analyses

1. Extract the complete archive.
2. Start Jupyter with `notebooks/` as the working directory.
3. Open the notebook corresponding to the desired claim.
4. Confirm that its documented inputs are present under `../data/`.
5. Execute the notebook if reproduction is desired.

Most notebooks can be inspected independently from their recorded JSON or CSV result. Re-executing analyses that consume omitted pickle checkpoints requires running the named producer or worker notebooks first; the required order is listed in `CLAIM_TO_ARTIFACT.md`.

`CLAIM_TO_ARTIFACT.md` identifies the notebook, inputs, and recorded output supporting each principal paper result.

## Notes

- EX and EF prefixes are internal experiment and formalism identifiers.
- Graph targets are controlled structural coordinates, not claims of classical computational difficulty.
- Finite-shot experiments model multinomial measurement sampling. They do not model gate, compilation, device, or readout noise.
- External repositories are not required to inspect this archive.
- If a separately named certificate file is absent, the completed output of the corresponding notebook is the run-of-record artifact.
